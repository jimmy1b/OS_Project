/*
TCSS422 - Operating Systems
Problem 4

Group Members:
Joshua Lau
Alisher Baimenov
*/

#include <time.h>
#include "OS.h"


unsigned int sysStack;
unsigned int currentPC;
unsigned int dispatchCount;
PCB_p * privilegedPCBs[4]; // array of PCBs
unsigned int privilegedCount;
unsigned int quantum;
unsigned int quantumCounter;
unsigned int processCounter;
unsigned int theTime, IO1time, IO2time;
PCB_p * IO1Process;
PCB_p * IO2Process;
FIFO_Queue_p IO1Queue;
FIFO_Queue_p IO2Queue;

// The os simulator, runs the main loop.
int OS_Simulator(FIFO_Queue_p newProcesses, FIFO_Queue_p dieingProcesses, PriorityQ_p * readyProcesses, PCB_p * runningProcess) {
    srand(time(NULL));

    int iteration = 1;
    int t, a, i, j;
    startTimer(get_priority(*readyProcesses));
    // Main Loop
    // One cycle is one quantum
    for( ; ; ) { // for spider
        // stops making processes after 48 and if there are at least 4 Privileged pcbs
        if(processCounter < 48) {// && privilegedCount < 4) {
            createNewProcesses(newProcesses);
            processCounter += fifo_size(newProcesses);
        }

        // set new processes to ready
        while(!fifo_is_empty(newProcesses)) {
            // dequeue and print next pcb
            PCB_p pcb = fifo_dequeue(newProcesses);
            set_state(pcb, ready);

            // enqueue
            pq_enqueue(*readyProcesses, pcb);
        }


        //Simulate Process Running
        set_pc(*runningProcess, get_pc(*runningProcess) + 1);

        // Push to SysStack
        sysStack = currentPC;

        quantumCounter--;


       t = timer(*runningProcess);


        	for( ; ; ) {


	       if (t == 1) {
	       		pseudoISR(readyProcesses, dieingProcesses, runningProcess);
		        print_priority_queue(*readyProcesses);

		        break;
		    }

		    a = IOTrap1(IO1Queue, runningProcess, readyProcesses);

		    if (a == 1) {
		    	//throw io 1 interrupt
		    	break;
		    }

		    a = IOTrap2(IO2Queue, runningProcess, readyProcesses);
		    if (a == 1) {
		    	//throw io 2 interrupt
		    	break;
		    }
	       		break;
	       }

		//Terminate
		if (get_terminate(*runningProcess) > 0) {
			if (get_pc(*runningProcess) > get_max_pc(*runningProcess)) {
				set_term_count(*runningProcess, get_term_count(*runningProcess) + 1);
				set_pc(*runningProcess, 0);
				if (get_term_count(*runningProcess) > get_terminate(*runningProcess)) {
                    set_state(*runningProcess, halted);
                    scheduler(readyProcesses, dieingProcesses, runningProcess, get_state(*runningProcess));
				}
			}
		}
		iteration ++;
		//printf("ITERATION IS: %d\n", iteration);
        if (iteration == 30000)  break;
    }
}

int IOTrap1(FIFO_Queue_p IOQueue, PCB_p* runningProcess, PriorityQ_p * readyProcesses) {
	if (io_contains_pc(*runningProcess) == 1) {//enter logic to enqueue pcb into IO1queue if value matches the IO1 array.
        fifo_enqueue(IOQueue, *runningProcess);
	}


	if (IO1time <= 0) {
		printf(" I/O Trap 1 threw interrupt\n");
		IO1time = (rand() * 3 + 2) * 3 * getCyclesFromPriority(7) ;
        if (IO1Process != NULL) {
            pq_enqueue(readyProcesses, IO1Process);
        }
		IO1Process = fifo_dequeue(IOQueue);
		return 1;

	}
	else {
		IO1time -= 1;
		return 0;
	}

}
int IOTrap2(FIFO_Queue_p IOQueue, PCB_p* runningProcess, PriorityQ_p * readyProcesses) {
	if (io_contains_pc(*runningProcess) == 2) {//enter logic to enqueue pcb into IO1queue if value matches the IO1 array.
        fifo_enqueue(IOQueue, *runningProcess);
	}
	if (IO2time <= 0) {
		printf(" I/O Trap 2 threw interrupt\n");
		IO2time = (rand() * 3 + 2) * 3 * getCyclesFromPriority(7) ;
        if (IO2Process != NULL) {
            pq_enqueue(readyProcesses, IO2Process);
        }
		IO2Process = fifo_dequeue(IOQueue);
		return 1;

	}
	else {
		IO2time -= 1;
		return 0;
	}

}

// The psuedo-ISR, sets the state of the running process,
// calls the scheduler and updates the PC.
int pseudoISR(PriorityQ_p * readyProcesses, FIFO_Queue_p dieingProcesses, PCB_p* runningProcess) {
    // Sets the status to interrupted.
    set_state(*runningProcess, interrupted);

    // save pc to pcb
    set_pc(*runningProcess, currentPC);

    // scheduler up call
    scheduler(readyProcesses, dieingProcesses, runningProcess, get_state(*runningProcess));

    // IRET (update current pc)
    currentPC = sysStack;
    return SUCCESSFUL;
}
int startTimer(int priority) {
	theTime = priority * 100 + 100;
}

int timer(PCB_p pcb) {
	if (theTime <= 0) {
        startTimer(get_priority(pcb));
        return 1;
    }
	else {
		theTime -= 1;
		return 0;
	}
}

// Runs the scheduler to handle interrupts.
int scheduler(PriorityQ_p * readyProcesses, FIFO_Queue_p dieingProcesses, PCB_p* runningProcess, int interrupt) {
    switch(interrupt) {
        case interrupted:
            dispatcher(readyProcesses, runningProcess);
            break;
        case halted: // if the state is interrupted move to dieing processes and then call the dispatcher.
            fifo_enqueue(dieingProcesses, *runningProcess);
            dispatcher(readyProcesses, runningProcess);
            break;
        default:
            // error handling as needed
            break;
    }

    // housekeeping if needed
    // If there are 4 terminated processes, clear them now.
    if(fifo_size(dieingProcesses) == 4) {
        while(!fifo_is_empty(dieingProcesses)) {
            PCB_p dieingPCB = fifo_dequeue(dieingProcesses);
            destroy_pcb(dieingPCB);
        }

    }
    // after some time S move all processes into Q0.
    if(quantumCounter == 0) {
        moveProcesses(readyProcesses);
        quantumCounter = quantum;
    }

    return SUCCESSFUL;
}

// Dispatched the running process to appropriate queue.
int dispatcher(PriorityQ_p * readyProcesses, PCB_p* runningProcess) {
    // increment and check
    dispatchCount++;

    // update context if the pcb was not halted.
    if(get_state(*runningProcess) != halted) {
        // update the pc counter.
        set_pc(*runningProcess, sysStack);
        // set state.
        set_state(*runningProcess, ready);

        // Increments the cycles of the process.
        unsigned int cycles = get_cycles(*runningProcess);
        unsigned char priority = get_priority(*runningProcess);

        if (cycles % getCyclesFromPriority(priority) == 0) {
            if (priority == MAX_PRIORITY) {
                set_priority(*runningProcess, 0); // will go back to the highest priority queue
            } else {
                set_priority(*runningProcess, priority + 1);
            }
        }
        cycles++;
        set_cycles(*runningProcess, cycles);

        // enqueue
        pq_enqueue(*readyProcesses, *runningProcess);
    }

    // dequeue
    *runningProcess = pq_dequeue(*readyProcesses);

    // update state to running
    // set state
    set_state(*runningProcess, running);

    sysStack = get_pc(*runningProcess);

    return SUCCESSFUL;
}

void moveProcesses (PriorityQ_p * readyProcesses) {
    PriorityQ_p tempQueue = create_pq();
    while(!pq_isEmpty(*readyProcesses)) {

        PCB_p tempPCB = pq_dequeue(*readyProcesses);
        set_priority(tempPCB, 0);
        pq_enqueue(tempQueue, tempPCB);
    }

    *readyProcesses = tempQueue;
}

// Creates a random number of processes to be added to the
// the list of new processes.
int createNewProcesses(FIFO_Queue_p newProcesses) {
    int i;
    for(i = 0; i < rand() % 5; i++) {
        PCB_p pcb = create_pcb();

        // 20% chance that the pcb will become privileged.
        /*if(rand() % 100 < 20 ) {//&& privilegedCount < 4)  {
            setPrivileged(pcb);
            privilegedPCBs[privilegedCount] = pcb;
            privilegedCount++;
        })*/
        fifo_enqueue(newProcesses, pcb);
    }
}

// Returns the number of cycles that each queue uses.
unsigned int getCyclesFromPriority(unsigned int priority) {
    return 2 * (priority + 1);
}

// Main, to jump start the OS simulation and initialize variables.
int main() {
    // Seed RNG
    srand(time(NULL));

    // Initialize Vars
    FIFO_Queue_p newProcesses = create_fifo_queue();
    PriorityQ_p readyProcesses = create_pq();
    PCB_p runningProcess = create_pcb();
    FIFO_Queue_p dieingProcesses = create_fifo_queue();
    dieingProcesses = create_fifo_queue();
    PCB_p IO1Process = create_pcb();
    PCB_p IO2Process = create_pcb();
    IO1Queue = create_fifo_queue();
    IO2Queue = create_fifo_queue();
    // set a process to running
    set_state(runningProcess, running);

    currentPC = 0;
    sysStack = 0;
    dispatchCount = 0;
    privilegedCount = 0;
    quantum = 3 * getCyclesFromPriority(7); // multiple of middle queues quantum size.
    quantumCounter = quantum;
    processCounter = 1;

    // main loop
    OS_Simulator(newProcesses, dieingProcesses, &readyProcesses, &runningProcess);

    // free resources
    destroy(newProcesses);
    destroy(dieingProcesses);
    destroy_pq(readyProcesses);
    destroy_pcb(runningProcess);
    destroy(IO1Queue);
    destroy(IO2Queue);
    destroy_pcb(IO1Process);
    destroy_pcb(IO2Process);
}
